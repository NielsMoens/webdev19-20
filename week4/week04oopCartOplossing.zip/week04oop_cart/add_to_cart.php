<?php
 require_once 'app.php';


if(isset($_GET['product_code']) && isset($_GET['price'])) {
    $cart = new Cart();

    $product_code = $_GET['product_code'];
    $price = (float) $_GET['price'];
    $quantity = (int) isset($_GET['quantity']) ? $_GET['quantity'] : 1;

    $cartItem = new CartItem($product_code, $price, $quantity);
    $cart->add($cartItem);

}
header( 'location: cart.php');
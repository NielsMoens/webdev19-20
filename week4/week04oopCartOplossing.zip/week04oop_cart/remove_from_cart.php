<?php
 require_once 'app.php';
if(isset($_GET['key'])) {
    $cart->remove((int) $_GET['key']);
}
header( 'location: cart.php');
<?php 
require_once 'app.php';
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="<?php echo BASE_PATH; ?>css/style.css?v3">
</head>
<body>
<section>
<?php
    
    echo '<a href="' . BASE_PATH . 'cart.php">Shoppingcart (' . $cart->getNumberOfItems() . ')</a>';

    getProductsGrid($products);

?>
</section>
</body>
</html>

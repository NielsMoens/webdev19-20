<?php

const BASE_PATH = '';

//autoload data / models / controllers

require_once 'products_data.php';
    
require_once 'models/Cart.php';
require_once 'models/CartItem.php';

require_once 'controllers/products.php';
require_once 'controllers/cart.php';

//autoload cart
$cart = new Cart();